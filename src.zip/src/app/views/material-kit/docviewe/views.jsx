import React from 'react'

const views = () => {
  return (
    <div>views</div>
  )
}

export default views